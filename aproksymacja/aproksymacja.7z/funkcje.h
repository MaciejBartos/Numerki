#ifndef APROKSYMACJA_FUNKCJE_H
#define APROKSYMACJA_FUNKCJE_H

double wielomian(double x, int k);
double modul(double x, int k);
double trygonometryczna(double x, int k);
double wykladnicza(double x, int k);

#endif //APROKSYMACJA_FUNKCJE_H
