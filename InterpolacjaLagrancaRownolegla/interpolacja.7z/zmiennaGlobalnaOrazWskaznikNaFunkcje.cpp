
const int iloscPunktow = 100;

typedef double (*funkcja)(double);
