

#ifndef INTERPOLACJALAGRANCAROWNOLEGLA_ZAPISORAZODCZYT_H
#define INTERPOLACJALAGRANCAROWNOLEGLA_ZAPISORAZODCZYT_H

void odczytZPlikuWezly(double *tabX, double *tabY, int n);
void zapisDoPlikuWezly(double *tabX, double *tabY, int n);
void zapisDoPlikuInterpolacja(double *tabX, double *tabY);
void zapisDoPlikuInterpolowana(double *tabX, double *tabY);
#endif //INTERPOLACJALAGRANCAROWNOLEGLA_ZAPISORAZODCZYT_H
