#ifndef METODYBISEKCJIORAZNEWTONA_ZAPISDOFUNKCJI_H
#define METODYBISEKCJIORAZNEWTONA_ZAPISDOFUNKCJI_H

#include "funkcje.h"

void miejscaZeroweDoPliku(funkcja fun, double miejsceBisekcja, double miejsceNewtona);

void punktyDoNarysowaniaWykresu(double a, double b, funkcja fun);


#endif //METODYBISEKCJIORAZNEWTONA_ZAPISDOFUNKCJI_H
